package com.example.quotes

data class QuoteModel(
    val q: String,
    val a: String,
    val h: String
)
